#!/bin/bash


ipad=`curl ip.cip.cc`
[ -z $ipad ]  && exit 
echo $ipad



function check_zabbixdir () {
if [ ! -d /usr/local/zabbix ];then
    mv zabbix /usr/local/
    useradd zabbix -s /sbin/nologin
	chown zabbix:zabbix -R /usr/local/zabbix
fi
}


function modify_zabbix_ag_conf () {
if [ -d /usr/local/zabbix ] ;then
   sed -i 's/^ServerActive=.*/ServerActive=monitor-3.haowan123.com:10051,113.196.57.31:10051/' /usr/local/zabbix/etc/zabbix_agentd.conf
   sed -i "s/^Hostname=.*/Hostname=hxbns_tw-${ipad}/" /usr/local/zabbix/etc/zabbix_agentd.conf
   sed -i 's/^Server=.*/Server=monitor-3.haowan123.com,113.196.57.31/' /usr/local/zabbix/etc/zabbix_agentd.conf
   sed -i "s/^ListenIP=.*/#ListenIP=/" /usr/local/zabbix/etc/zabbix_agentd.conf
   sed -i 's/^ListenPort=.*/#ListenPort=/' /usr/local/zabbix/etc/zabbix_agentd.conf
   /bin/mv zabbix_agentd /etc/init.d/zabbix_agentd
   chmod +x /etc/init.d/zabbix_agentd
   chmod +x /usr/local/zabbix/sbin/*
   /sbin/chkconfig --add zabbix_agentd 
   /sbin/chkconfig --levels 235 zabbix_agentd on 
else
   echo zabbix dont exist...
fi

}

check_zabbixdir &&  modify_zabbix_ag_conf   

/etc/init.d/zabbix_agentd
/etc/init.d/zabbix_agentd start
netstat -nltp |grep za
