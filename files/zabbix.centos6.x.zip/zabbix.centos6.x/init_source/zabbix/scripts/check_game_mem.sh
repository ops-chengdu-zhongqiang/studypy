#!/bin/bash
#check the memory used by gs
OK=0
WARNING=1
CRITICAL=2
UNKNOWN=3

GS_WARN=5000
LS_WARN=5000
GS_CRITICAL=10000
LS_CRITICAL=10000

#set the default value
LS_MEMUSED=0
GS_MEMUSED=0
DBS_MEMUSED=0
FunS_MEMUSED=0
COMMONS_MEMUSED=0
Command=$1

GSPID=$(ps -ef|grep beam|grep $Command@127.0.0.1|grep -v 'entop' |awk '{print $2}');
if [ ! -z $GSPID ]
then
    GS_MEMUSED=$(cat /proc/${GSPID}/status | grep 'VmRSS'| awk '{print $2}')
    GS_MEMUSED=$(echo "$GS_MEMUSED/1024" | bc)
fi
#echo $GSPID
echo $GS_MEMUSED

