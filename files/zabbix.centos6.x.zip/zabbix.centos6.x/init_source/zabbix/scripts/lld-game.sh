#!/bin/bash

aa=(`cat /usr/local/zabbix/scripts/pro_list.txt`)

len=${#aa[@]}
bb=$(($len-1))
echo "{"
echo "    "\"data\": "["
for ((i=0;i<$len;i++));do
        echo "        ""{"
        echo "            "\"{#NAME}\": \"${aa[$i]}\",
        echo "            "\"{#SIZE}\": \"${aa[$i]}\"
        if [ $i -lt $bb ];then
            echo "        ""}," 
        else
            echo "        ""}"
        fi
done
echo "    ""]"
echo "}"

