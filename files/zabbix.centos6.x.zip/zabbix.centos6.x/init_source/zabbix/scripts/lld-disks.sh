#!/bin/bash


aa=(`cat /proc/diskstats | awk '{print $3}' | egrep -v 'ram|loop|sr|md'`)
len=${#aa[@]}
bb=$(($len-1))
echo "{"
echo "    "\"data\": "["
for ((i=0;i<$len;i++));do
	echo "        ""{"
	echo "            "\"{#DEVICENAME}\": \"${aa[$i]}\",
	echo "            "\"{#DEVICE}\": \"${aa[$i]}\"
        if [ $i -lt $bb ];then
            echo "        ""}," 
	else
	    echo "        ""}"
        fi 
done
echo "    ""]"
echo "}"
