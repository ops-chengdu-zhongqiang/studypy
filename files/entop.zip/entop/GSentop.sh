cd /data/script/entop/entop-master && chmod +x entop
/data/script/entop/entop-master/entop gameserver@127.0.0.1 -name entopGS@127.0.0.1 -setcookie erlide








